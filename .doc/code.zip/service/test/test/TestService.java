package com.fh.service.test.test;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.fh.dao.DaoSupport;
import com.fh.entity.Page;
import com.fh.util.PageData;


@Service("testService")
public class TestService {

	@Resource(name = "daoSupport")
	private DaoSupport dao;
	
	/*
	* ����
	*/
	public void save(PageData pd)throws Exception{
		dao.save("TestMapper.save", pd);
	}
	
	/*
	* ɾ��
	*/
	public void delete(PageData pd)throws Exception{
		dao.delete("TestMapper.delete", pd);
	}
	
	/*
	* �޸�
	*/
	public void edit(PageData pd)throws Exception{
		dao.update("TestMapper.edit", pd);
	}
	
	/*
	*�б�
	*/
	public List<PageData> list(Page page)throws Exception{
		return (List<PageData>)dao.findForList("TestMapper.datalistPage", page);
	}
	
	/*
	*�б�(ȫ��)
	*/
	public List<PageData> listAll(PageData pd)throws Exception{
		return (List<PageData>)dao.findForList("TestMapper.listAll", pd);
	}
	
	/*
	* ͨ��id��ȡ����
	*/
	public PageData findById(PageData pd)throws Exception{
		return (PageData)dao.findForObject("TestMapper.findById", pd);
	}
	
	/*
	* ����ɾ��
	*/
	public void deleteAll(String[] ArrayDATA_IDS)throws Exception{
		dao.delete("TestMapper.deleteAll", ArrayDATA_IDS);
	}
	
}

